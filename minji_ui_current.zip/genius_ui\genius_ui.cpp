#include "genius_ui.h"
#include "eye.h"


namespace {

lv_obj_t* face_root = nullptr;

}  // namespace


void GeniusUI::Init(
    lv_obj_t* screen
)
{
    if (screen == nullptr) {
        return;
    }

    if (
        face_root != nullptr &&
        lv_obj_is_valid(face_root)
    ) {
        lv_obj_delete(face_root);
    }

    face_root = lv_obj_create(screen);

    lv_obj_remove_style_all(face_root);

    lv_obj_set_size(
        face_root,
        LV_HOR_RES,
        LV_VER_RES
    );

    lv_obj_align(
        face_root,
        LV_ALIGN_CENTER,
        0,
        0
    );

    lv_obj_set_style_bg_color(
        face_root,
        lv_color_black(),
        0
    );

    lv_obj_set_style_bg_opa(
        face_root,
        LV_OPA_COVER,
        0
    );

    lv_obj_set_style_border_width(
        face_root,
        0,
        0
    );

    lv_obj_set_style_pad_all(
        face_root,
        0,
        0
    );

    lv_obj_remove_flag(
        face_root,
        LV_OBJ_FLAG_SCROLLABLE
    );

    Eye::Create(face_root);

    lv_obj_move_foreground(face_root);
    lv_obj_invalidate(face_root);
}
